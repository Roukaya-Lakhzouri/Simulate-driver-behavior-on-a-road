RpTMoy=zeros(1,24);
OpTMoy=zeros(1,24);
GpTMoy=zeros(1,24);

for i=1:24
  OpTMoy(1,i)=(1/100)*sum(OrangeperTime(:,i));
  RpTMoy(1,i)=(1/100)*sum(RedperTime(:,i));
  GpTMoy(1,i)=(1/100)*sum(GreenperTime(:,i));
endfor
figure(1)
plot(RpTMoy)
xlabel('Number of Red cars');
ylabel('Hours');
figure(2)
plot(OpTMoy)
xlabel('Number of Orange cars');
ylabel('Hours');
figure(3)
plot(GpTMoy)
xlabel('Number of Green cars');
ylabel('Hours');
