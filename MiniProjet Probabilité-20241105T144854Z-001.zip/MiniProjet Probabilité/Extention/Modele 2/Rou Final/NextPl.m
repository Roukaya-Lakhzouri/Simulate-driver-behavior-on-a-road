function  NextPl ()
  global Pl;
  global Vl;
  global dt ;
  global RedperTime;
  global GreenperTime ;
  global OrangeperTime ;
  global M;
  global T1;

  Nl=size(Pl)(1);
  for (i=1:Nl)
     Pl(i,2)+=Vl(i,2)*dt;
     Pl(i,1)+=Vl(i,1)*dt;
    if Pl(i,3)==0
      GreenperTime(M,floor(T1/60)+1)=GreenperTime(M,floor(T1/60)+1)+1 ;
    elseif Pl(i,3)==2
      RedperTime(M,floor(T1/60)+1)=RedperTime(M,floor(T1/60)+1)+1;
    else
      OrangeperTime(M,floor(T1/60)+1)=OrangeperTime(M,floor(T1/60)+1)+1;
    end  ;
  endfor
endfunction
