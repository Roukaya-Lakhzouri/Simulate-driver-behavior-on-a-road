function p=p(T)
  global dt;
  a=T/60;
  e=@(t) (((1/(sqrt(2*pi*2)))*exp(-((t-11)^2)/4)+(1/(sqrt(2*2*pi)))*exp(-((t-16)^2)/4)+(1/(sqrt(2*pi)))*exp(-((t-7)^2)/2)))/2.5;
  p=quad(e,a,a+dt);
endfunction

