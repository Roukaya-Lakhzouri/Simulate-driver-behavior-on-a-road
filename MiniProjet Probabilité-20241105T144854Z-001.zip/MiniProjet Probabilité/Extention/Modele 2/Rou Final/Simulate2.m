function Simulate2 ()
  global Pl;
  global Ph;
  global T1;
  global nr;
  global no;
  global nv;
  N=size(Pl)(1);
  M=size(Ph)(1);
  clf
  hold on
  h=rectangle ("Position", [0, -10,40,8], "Curvature", [0, 0]);
  set (h, "FaceColor", [0.5, 0.5, 0.5],'EdgeColor',[0.5, 0.5, 0.5]);
  y = -6; % position y de la ligne
  axis([0 40 -10 30]);
  axis off;
  x=[0,40];
  line(x, [-6, -6], 'Color', 'white', 'LineStyle', '--', 'LineWidth', 3);
  h1=rectangle ("Position", [16, -2, 8,22], "Curvature", [0, 0]);
  set (h1, "FaceColor", [0.5, 0.5, 0.5],'EdgeColor',[0.5, 0.5, 0.5]);
  line([20,20],[-2,20], 'Color', 'white', 'LineStyle', '--', 'LineWidth', 3);
  h2=rectangle ("Position", [24,6,16,5], "Curvature", [0, 0]);
  set (h2, "FaceColor", [0.5, 0.5, 0.5],'EdgeColor',[0.5, 0.5, 0.5]);
  %line([22,22],[-2,20], 'Color', 'white', 'LineStyle', '--', 'LineWidth', 3);
  h4=rectangle ("Position", [30.5, 3.5, 4,2], "Curvature", [0.5, 0.5]);
  text(5.5,10.75,'Number of red cars:','FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;
  text(5.5,8.75,'Number of green cars:','FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;
  text(5.5,6.75,'Number of orange cars:','FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;
  %plotting colored cars
  for i=1:N
    if Pl(i,3)==0
      nv+=1;
      plot(Pl(i,1),Pl(i,2),'s', 'MarkerFaceColor', 'green', 'MarkerEdgeColor', 'black','MarkerSize',12);
    elseif Pl(i,3)==1
      no+=1;
      plot(Pl(i,1),Pl(i,2),'s', 'MarkerFaceColor', [1, 0.5, 0], 'MarkerEdgeColor', 'black','MarkerSize',12);
    else Pl(i,3)==2
      nr+=1;
      plot(Pl(i,1),Pl(i,2),'s', 'MarkerFaceColor', 'red', 'MarkerEdgeColor', 'black','MarkerSize',12);
    endif;
    if Pl(i,4)==1
      text(Pl(i,1),Pl(i,2),'T');
    elseif Pl(i,4)==0
      text(Pl(i,1),Pl(i,2),'S');
    endif;
  endfor
  for i=1:M
    if Ph(i,3)==0
      nv+=1;
      plot(Ph(i,1),Ph(i,2),'s', 'MarkerFaceColor', 'green', 'MarkerEdgeColor', 'black','MarkerSize',12);
    elseif Ph(i,3)==1
      no+=1;
      plot(Ph(i,1),Ph(i,2),'s', 'MarkerFaceColor', [1, 0.5, 0], 'MarkerEdgeColor', 'black','MarkerSize',12);
    else Ph(i,3)==2
      nr+=1;
      plot(Ph(i,1),Ph(i,2),'s', 'MarkerFaceColor', 'red', 'MarkerEdgeColor', 'black','MarkerSize',12);
    endif
    if Ph(i,4)==1
      text(Ph(i,1),Ph(i,2),'T');
    elseif Ph(i,4)==0
      text(Ph(i,1),Ph(i,2),'S');
    endif
  endfor
  [h,m]=convertirMinutes(T1);
  hs=num2str(h);
  ms=num2str(m);
  time=strcat(hs,':',ms);
  text(32.5,4.75,time,'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;
  drawnow
  text(11.5,10.75,num2str(nr),'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;

  text(12.5,8.75,num2str(nv),'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;

  text(12.5,6.75,num2str(no),'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center') ;

  hold off;
  %pause seépratiion temporelle
endfunction

