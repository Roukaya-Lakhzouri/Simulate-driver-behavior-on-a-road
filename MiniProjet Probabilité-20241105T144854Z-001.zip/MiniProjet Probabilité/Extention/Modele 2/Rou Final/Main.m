%Variables
%les vecteurs sont notés en majiscule et les autres en miniscule
global Lx=40;
global Vmax ;
Vmax=1.8;
global Amax ;
Amax=1.4;

global Ph;%Pos high
Ph=[Lx,7.5,0,0,0,0];
global Vh ;%Vitesse high
Vh=[rand()*Vmax,0];
global Pl ;%Pos low
Pl=[0,-8,0,0,0];
global Vl ;%Vitesse  low
Vl=[rand()*Vmax,0];
global xth=22; %turn position
global xtch=24 ; %coin position
global xtl=17; %turn position
global xtcl=14; %coin position
global xdecel=10 ; %zone décélération des Tcars qui veulent tourner
global xmid=20 ; % position du milieu
global dt;% pas de temps
global xhsafe=24 ; %début du zone décélération high
global xlsafe=10; % début du zone décélération low
global Ly=20;
global s=2*dt ; % safety time
global d1=2;   %d1 and d2 are the values determining if a car is close to be in traffic or in actual traffic or neither
global d2=4;
global W;
global WL;
global m;
global M;
global temhT;
global temlS;
global temhS;
global temlT;
global RedperTime;
global GreenperTime ;
global OrangeperTime ;
RedperTime=zeros(100,24) ;
GreenperTime=zeros(100,24);
OrangeperTime=zeros(100,24);
temhT=[];
temhS=[];
temlT=[];
temlS=[];

m=0;
WL=0;
global T1;
T1=0 ;
global T2;
T2=1439 ;
%Main
Z=0 ;
global nr;
global no;
global nv;
global MC;
MC=100;%montecarlo
Nrouge_f=0;
Nvert_f=0;
Norange_f=0;
TSR=zeros(1,M);
TSV=zeros(1,M);
TSO=zeros(1,M);
Nr=zeros(1,(T2-T1));
Nv=zeros(1,(T2-T1));
Nrouge=0;
Nvert=0;
Norange=0;
ThT_f=zeros(1,MC);
ThS_f=zeros(1,MC);
TlT_f=zeros(1,MC);
TlS_f=zeros(1,MC);
for M=1:MC
  Nrouge=[];
  Nvert=[];
  Norange=[];
  T=[];
  Z=0 ;
  ThS=0;
  TlS=0;
  ThT=0;
  TlT=0;
  T1=0;
  nr=0;
  no=0;
  nv=0;
  while (T1<T2);
    %updating speed and position for the higher cars
    for i=1:size(Vh)(1)
      if Ph(i,4)==1
        VhT(i) ;
      else
        Vhdt(i);
      end;
      Ph(i,5)+=dt;
    endfor;
    NextPh();

    %updating speed and position for the lower cars
    for i=1:size(Vl)(1)
      if Pl(i,4)==1
        VlT(i) ;
      else
        Vldt(i);
      end;
      Pl(i,5)+=dt;
    endfor;
    NextPl();
    %adding the new cars
    Add_cars() ;
    Delete() ;
    Traffic_state() ;
    Simulate2() ;
    Z+=1;
    Norange=[Norange;no];
    Nvert=[Nvert;nv];
    Nrouge=[Nrouge;nr];
    T=[T;T1];
    T1+=dt ;
  endwhile ;
  for l=1:size(T)(1)
    Nrouge_f+=Nrouge(l,1);%moyen des car rouge a l'instant T[i]
    Nvert_f+=Nvert(l,1);%moyen des car vert a l'instant T[i]
    Norange_f+=Norange(l,1);%%moyen des car orange a l'instant T[i]
    Nr(l)+=Nrouge(l,1)/MC;
    Nv(l)+=Nvert(l,1)/MC;
  endfor
  TSR(M)=Nrouge_f/Z;
  TSV(M)=Nvert_f/Z;
  TSO(M)=Norange_f/Z;
  for l=1:(size(temhT)(1))
    ThT+=temhT(1,l);
  endfor
  for l=1:(size(temhS)(1))
    ThS+=temhS(1,l);
  endfor
  for l=1:(size(temlT)(1))
    TlT+=temlT(1,l);
  endfor
  for l=1:(size(temlS)(1))
    TlS+=temlS(1,l);
  endfor
  ThT_f(1,M)+=ThT/(size(temhS)(1));
  ThS_f(1,M)+=ThS/(size(temhS)(1));
  TlT_f(1,M)+=TlT/(size(temlT)(1));
  TlS_f(1,M)+=TlS/(size(temlS)(1));
  M
endfor

%tu peut simuler  Norange_f Nvert_f Nrouge_f en fonction de temps
%plot(1:M,TSR)
%plot(1:M,TSV)
%plot(1:M,TSO)
%plot(T,Nr)
%plot(T,Nv)

