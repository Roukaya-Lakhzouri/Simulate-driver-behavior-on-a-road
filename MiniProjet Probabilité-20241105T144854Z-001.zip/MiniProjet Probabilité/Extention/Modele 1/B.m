function y = B (K)
  y=0;
  i = rand ();
  if (i <= K)
    y = 1;
  else
    y = 0;
  endif
endfunction

