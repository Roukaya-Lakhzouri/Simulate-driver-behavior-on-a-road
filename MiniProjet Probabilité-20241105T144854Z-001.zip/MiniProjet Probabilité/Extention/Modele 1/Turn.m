function t= Turn (p)
  global d ;
  x=rand();
  if x>=p
    t=0 ;
  else
    t=1 ;
  endif
endfunction
